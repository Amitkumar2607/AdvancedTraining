export class Addmedicine {
    medicineName!: string;
    manufactureDate!: string;
    type!: string;
    price!: string;
    description!: string;
    expireDate!: string;
    status!: string;
    seller!: string;
}